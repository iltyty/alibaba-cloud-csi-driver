# 商超联盟门店数据传输系统 - 项目报告

## 一、项目概述

本项目为商超联盟设计了一个基于分布式计算模式的门店与服务中心数据上传系统。系统支持TCP和UDP两种传输协议，能够处理多种格式的数据源（xlsx、csv），并实现了数据压缩、并发连接、传输统计等功能。

### 1.1 系统架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                         系统架构图                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────────┐          UDP:8000           ┌─────────────┐ │
│   │              │ ◄──── 数据传输请求 ────────►  │             │ │
│   │              │ ◄──── 协议选择(0/1) ───────► │             │ │
│   │    客户端    │                              │   服务端    │ │
│   │  (client.py) │ ◄─── 分配端口通知 ──────────│ (server.py) │ │
│   │              │                              │             │ │
│   └──────┬───────┘                              └──────┬──────┘ │
│          │                                             │        │
│          │         TCP/UDP (随机端口)                  │        │
│          │  ┌─────────────────────────────────┐       │        │
│          └──┤  压缩数据传输 (zlib + JSON)     ├───────┘        │
│             └─────────────────────────────────┘                 │
│                                                                 │
│   数据流向：                                                    │
│   门店数据(A.xlsx/B.csv/C.csv/D.csv)                           │
│        ↓                                                        │
│   数据标准化 → 压缩 → 网络传输 → 解压 → 写入service.xlsx       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 二、通信流程详解

### 2.1 完整通信时序图

```
┌────────┐                                              ┌────────┐
│ 客户端 │                                              │ 服务端 │
└───┬────┘                                              └───┬────┘
    │                                                       │
    │  1. UDP请求: "数据传输请求"                           │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │  2. UDP响应: "请选择数据传输时的通信方式..."          │
    │ ◄─────────────────────────────────────────────────────│
    │                                                       │
    │  3. UDP请求: "0"(UDP) 或 "1"(TCP)                     │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │                          ┌────────────────────────────┤
    │                          │ 创建Handler线程            │
    │                          │ 绑定随机端口               │
    │                          │ 等待ready事件              │
    │                          └────────────────────────────┤
    │                                                       │
    │  4. UDP响应: "我已准备完毕，请开始传输:{port}"        │
    │ ◄─────────────────────────────────────────────────────│
    │                                                       │
    │  5. TCP连接 或 UDP发送 (到分配的端口)                 │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │  6. 循环发送压缩数据包                                │
    │     { store, index, data, last }                      │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │                          ┌────────────────────────────┤
    │                          │ 解压数据                   │
    │                          │ 写入Excel                  │
    │                          └────────────────────────────┤
    │                                                       │
    │  7. 发送最后一条数据 (last=true)                      │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │  8. 关闭连接                                          │
    │ ─────────────────────────────────────────────────────►│
    │                                                       │
    │                          ┌────────────────────────────┤
    │                          │ 保存文件                   │
    │                          │ 记录传输日志               │
    │                          └────────────────────────────┤
    │                                                       │
```

### 2.2 数据包格式

每条传输的数据包结构如下：

```json
{
    "store": "A",           // 门店标识
    "index": 0,             // 数据序号
    "data": {               // 标准化后的商品数据
        "retailer_code": "xxx",
        "prod_desc": "xxx",
        "normal_price": 99.9,
        "unit_dimension": "个",
        "unit_number": 10
    },
    "last": false           // 是否为最后一条数据
}
```

**数据处理流程：**
1. JSON序列化 → UTF-8编码 → zlib压缩 → 网络传输
2. 接收端：zlib解压 → UTF-8解码 → JSON反序列化

---

## 三、运行说明

### 3.1 环境准备

```bash
# 1. 克隆或进入项目目录
cd retailers-mesh

# 2. 创建虚拟环境
python -m venv .venv

# 3. 激活虚拟环境
# macOS/Linux:
source .venv/bin/activate
# Windows:
.venv\Scripts\activate

# 4. 安装依赖
pip install -r requirements.txt
```

**依赖说明 (requirements.txt)：**
```
openpyxl>=3.1.0    # Excel文件读写
pandas>=2.0.0      # CSV数据处理
faker>=20.0.0      # 测试数据生成
```

### 3.2 服务端运行

```bash
python server.py [选项]
```

**支持的参数：**

| 参数 | 简写 | 默认值 | 说明 |
|------|------|--------|------|
| `--port` | `-p` | 8000 | 服务端监听的UDP端口 |

**示例：**
```bash
# 使用默认端口8000启动
python server.py

# 指定端口9000启动
python server.py -p 9000
```

**输出文件：**
- `service.xlsx` - 接收到的数据，每个门店对应一个Sheet
- `transfer_log.txt` - 传输日志，记录每次传输的统计信息

### 3.3 客户端运行

```bash
python client.py [选项]
```

**支持的参数：**

| 参数 | 简写 | 默认值 | 说明 |
|------|------|--------|------|
| `--host` | `-H` | 127.0.0.1 | 服务器地址 |
| `--port` | `-p` | 8000 | 服务器端口 |

**示例：**
```bash
# 连接本地服务器
python client.py

# 连接远程服务器
python client.py -H 192.168.1.100 -p 9000
```

**交互流程：**
```
选择想要传输的门店信息：A/B/C/D，退出请输入exit
> A
请选择数据传输时的通信方式，基于TCP请选择1，基于UDP请选择0
> 1
开始传输数据
数据传输完成，共传输 XXX 条记录，耗时 X.XXX 秒
```

---

## 四、服务端实现详解

### 4.1 模块架构

```
server.py
├── TransferStats        # 传输统计类
├── DataWriter           # 数据写入器（线程安全）
├── TCPHandler           # TCP数据接收处理器（线程）
├── UDPHandler           # UDP数据接收处理器（线程）
└── Server               # 服务端主类
```

**类关系图：**

```
┌─────────────────────────────────────────────────────────┐
│                        Server                           │
│  - port: int                                            │
│  - writer: DataWriter                                   │
│  - handlers: list[Handler]                              │
│  + start()                                              │
│  + _handle_client()                                     │
│  + _find_free_port()                                    │
└───────────────────┬─────────────────────────────────────┘
                    │ 创建
        ┌───────────┴───────────┐
        ▼                       ▼
┌───────────────┐       ┌───────────────┐
│  TCPHandler   │       │  UDPHandler   │
│  (Thread)     │       │  (Thread)     │
├───────────────┤       ├───────────────┤
│ - port        │       │ - port        │
│ - writer      │       │ - writer      │
│ - stats       │       │ - stats       │
│ - ready       │       │ - ready       │
│ + run()       │       │ + run()       │
└───────┬───────┘       └───────┬───────┘
        │                       │
        └───────────┬───────────┘
                    │ 使用
        ┌───────────┴───────────┐
        ▼                       ▼
┌───────────────┐       ┌───────────────┐
│  DataWriter   │       │ TransferStats │
│               │       │               │
├───────────────┤       ├───────────────┤
│ - lock        │       │ - start_time  │
│ - wb          │       │ - end_time    │
│ + write()     │       │ - record_count│
│ + save()      │       │ + save_log()  │
└───────────────┘       └───────────────┘
```

### 4.2 TransferStats - 传输统计类

```python
class TransferStats:
    """传输统计类 - 记录每次传输的性能指标"""
    
    def __init__(self, store: str, protocol: str):
        self.store = store          # 门店标识
        self.protocol = protocol    # 传输协议
        self.start_time = None      # 开始时间
        self.end_time = None        # 结束时间
        self.record_count = 0       # 记录数量
```

**功能说明：**
- `start()` - 记录传输开始时间
- `finish()` - 记录传输结束时间
- `duration` - 计算传输总时长
- `save_log()` - 将统计信息追加到日志文件

### 4.3 DataWriter - 数据写入器

```python
class DataWriter:
    """数据写入器 - 线程安全的Excel写入"""
    
    def __init__(self, output_file: str = "service.xlsx"):
        self.output_file = output_file
        self.lock = threading.Lock()  # 线程锁
        self._init_workbook()
```

**关键特性：**

1. **线程安全**：使用 `threading.Lock()` 保护写入操作
2. **按门店分Sheet**：每个门店的数据存储在独立的Sheet中
3. **延迟保存**：`write_record()` 只写入内存，`save()` 才持久化到磁盘

```python
def write_record(self, store: str, data: dict):
    with self.lock:  # 获取锁
        if store not in self.wb.sheetnames:
            ws = self.wb.create_sheet(store)
            ws.append(["retailer_code", "prod_desc", ...])
        else:
            ws = self.wb[store]
        ws.append([...])  # 写入数据行

def save(self):
    with self.lock:  # 获取锁
        self.wb.save(self.output_file)  # 持久化
```

### 4.4 并发连接处理

**连接管理机制：**

```
                    ┌─────────────────┐
                    │   主UDP Socket  │
                    │   端口: 8000     │
                    └────────┬────────┘
                             │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
          ▼                  ▼                  ▼
   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
   │ Handler线程1│    │ Handler线程2│    │ Handler线程3│
   │ 端口: 50001 │    │ 端口: 50002 │    │ 端口: 50003 │
   └─────────────┘    └─────────────┘    └─────────────┘
```

**实现要点：**

1. **主线程监听固定端口**：接收所有客户端的初始请求
2. **动态分配端口**：为每个数据传输连接分配随机可用端口
3. **独立Handler线程**：每个客户端连接由独立线程处理
4. **Event同步**：使用 `threading.Event` 确保端口绑定完成后再通知客户端

```python
def _find_free_port(self) -> int:
    """获取一个可用的随机端口"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))  # 绑定到随机端口
        return s.getsockname()[1]

def _handle_client(self, data, addr, sock):
    port = self._find_free_port()
    handler = TCPHandler(port, self.writer, store)
    self.handlers.append(handler)
    handler.start()
    handler.ready.wait(timeout=5)  # 等待Handler准备就绪
    sock.sendto(f"我已准备完毕，请开始传输:{port}".encode(), addr)
```

### 4.5 TCP实现详解

**TCPHandler 工作流程：**

```
┌─────────────────────────────────────────────────────────┐
│                    TCPHandler.run()                      │
├─────────────────────────────────────────────────────────┤
│  1. 创建TCP Socket                                      │
│  2. 绑定端口并监听 (listen)                             │
│  3. 设置ready事件 ──► 通知主线程可以发送端口给客户端    │
│  4. accept() 等待客户端连接                             │
│  5. 循环接收数据:                                       │
│     ┌─────────────────────────────────────────────┐     │
│     │  recv() → 追加到buffer                      │     │
│     │           ↓                                 │     │
│     │  解析长度前缀协议:                          │     │
│     │  ┌─────────┬──────────────────────┐        │     │
│     │  │ 4字节   │     数据内容          │        │     │
│     │  │ 长度头  │   (zlib压缩)          │        │     │
│     │  └─────────┴──────────────────────┘        │     │
│     │           ↓                                 │     │
│     │  zlib.decompress() → JSON解析               │     │
│     │           ↓                                 │     │
│     │  DataWriter.write_record()                  │     │
│     └─────────────────────────────────────────────┘     │
│  6. 收到 last=true → 保存文件 → 记录日志               │
└─────────────────────────────────────────────────────────┘
```

**长度前缀协议解析（关键代码）：**

```python
# 解析长度前缀协议：每个数据包 = 4字节长度头 + 实际数据
while len(buffer) >= 4:
    # 从前4字节解析出数据长度（大端序无符号整数）
    msg_len = struct.unpack('>I', buffer[:4])[0]
    # 如果缓冲区数据不足一个完整包，等待更多数据
    if len(buffer) < 4 + msg_len:
        break
    # 提取完整的数据包
    data = buffer[4:4+msg_len]
    # 移除已处理的数据，保留剩余部分
    buffer = buffer[4+msg_len:]
```

**为什么需要长度前缀？**

TCP是流式协议，不保留消息边界。压缩后的二进制数据可能包含任意字节（包括常见的分隔符如 `\n`），因此使用4字节长度前缀来明确每个数据包的边界。

### 4.6 UDP实现详解

**UDPHandler 工作流程：**

```
┌─────────────────────────────────────────────────────────┐
│                    UDPHandler.run()                      │
├─────────────────────────────────────────────────────────┤
│  1. 创建UDP Socket                                      │
│  2. 绑定端口                                            │
│  3. 设置ready事件                                       │
│  4. 循环接收数据:                                       │
│     ┌─────────────────────────────────────────────┐     │
│     │  recvfrom() → 直接获取完整数据报             │     │
│     │           ↓                                 │     │
│     │  zlib.decompress() → JSON解析               │     │
│     │           ↓                                 │     │
│     │  DataWriter.write_record()                  │     │
│     └─────────────────────────────────────────────┘     │
│  5. 收到 last=true 或 超时 → 保存文件                   │
└─────────────────────────────────────────────────────────┘
```

**UDP vs TCP 实现差异：**

| 特性 | TCP | UDP |
|------|-----|-----|
| 消息边界 | 需要长度前缀 | 天然保持 |
| 数据接收 | `recv()` 到buffer | `recvfrom()` 直接获取 |
| 连接管理 | 需要 `accept()` | 无连接 |
| 超时处理 | 连接断开检测 | 10秒超时自动结束 |

---

## 五、客户端实现详解

### 5.1 模块架构

```
client.py
├── DataLoader           # 数据加载器（支持多种格式）
├── TransferStats        # 传输统计
├── TCPTransfer          # TCP传输器
├── UDPTransfer          # UDP传输器
└── Client               # 客户端主类
```

**类关系图：**

```
┌─────────────────────────────────────────────────────────┐
│                        Client                           │
│  - host: str                                            │
│  - port: int                                            │
│  - loader: DataLoader                                   │
│  + run()                                                │
│  + _select_store()                                      │
│  + _select_protocol()                                   │
│  + _transfer_data()                                     │
└───────────────────┬─────────────────────────────────────┘
                    │ 使用
        ┌───────────┴───────────┐
        ▼                       ▼
┌───────────────┐       ┌───────────────┐
│  DataLoader   │       │ TCPTransfer   │
├───────────────┤       │ UDPTransfer   │
│ + load(store) │       ├───────────────┤
│ + _load_xlsx()│       │ + connect()   │
│ + _load_csv_*()       │ + send()      │
└───────────────┘       │ + close()     │
                        └───────────────┘
```

### 5.2 DataLoader - 数据加载器

**支持的数据格式：**

| 门店 | 文件 | 格式 | 特点 |
|------|------|------|------|
| A | A.xlsx | Excel | 标准格式，直接读取 |
| B | B.csv | CSV | 标准CSV格式 |
| C | C.csv | CSV | 非结构化，列位置不固定 |
| D | D.csv | CSV | 非结构化，列位置不固定 |

**数据标准化处理：**

```python
def load(self, store: str):
    """加载门店数据并返回标准化记录"""
    if store == "A":
        return self._load_xlsx(filepath, store)
    elif store == "B":
        return self._load_csv_b(filepath, store)
    # ...
```

不同格式的CSV使用不同的解析策略，最终统一为：
```python
{
    "retailer_code": "...",
    "prod_desc": "...",
    "normal_price": 0.0,
    "unit_dimension": "...",
    "unit_number": 0
}
```

### 5.3 运行流程

```
┌────────────────────────────────────────────────────────┐
│                    Client.run()                         │
├────────────────────────────────────────────────────────┤
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │  1. 选择门店                                      │  │
│  │     输入: A/B/C/D 或 exit                        │  │
│  │     验证: 非法输入提示重新输入                   │  │
│  └──────────────────────────────────────────────────┘  │
│                         ↓                              │
│  ┌──────────────────────────────────────────────────┐  │
│  │  2. 发送"数据传输请求" (UDP)                     │  │
│  │     接收服务端响应                               │  │
│  └──────────────────────────────────────────────────┘  │
│                         ↓                              │
│  ┌──────────────────────────────────────────────────┐  │
│  │  3. 选择传输协议                                  │  │
│  │     输入: 0(UDP) 或 1(TCP)                       │  │
│  └──────────────────────────────────────────────────┘  │
│                         ↓                              │
│  ┌──────────────────────────────────────────────────┐  │
│  │  4. 发送协议选择 (UDP)                           │  │
│  │     接收分配的数据端口                           │  │
│  └──────────────────────────────────────────────────┘  │
│                         ↓                              │
│  ┌──────────────────────────────────────────────────┐  │
│  │  5. 建立数据连接并传输                           │  │
│  │     - 加载门店数据                               │  │
│  │     - 压缩并发送每条记录                         │  │
│  │     - 统计传输时间                               │  │
│  └──────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

### 5.4 数据压缩处理

**压缩流程：**

```python
for idx, record in enumerate(records):
    packet = {
        "store": store,
        "index": idx,
        "data": record,
        "last": (idx == total - 1)
    }
    # JSON序列化 → UTF-8编码 → zlib压缩
    compressed = zlib.compress(json.dumps(packet).encode("utf-8"))
    transfer.send(compressed)
```

**压缩效果：**
- 原始JSON约200字节 → 压缩后约80-100字节
- 压缩率约50%，显著减少网络传输量

### 5.5 TCP传输器实现

```python
class TCPTransfer:
    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))
    
    def send(self, data: bytes):
        # 发送4字节长度前缀 + 数据
        self.sock.sendall(struct.pack('>I', len(data)) + data)
    
    def close(self):
        if self.sock:
            self.sock.shutdown(socket.SHUT_WR)  # 优雅关闭
            time.sleep(0.1)  # 等待缓冲区数据发送完毕
            self.sock.close()
```

**关键点：**
- 使用 `struct.pack('>I', len(data))` 生成4字节大端序长度头
- 关闭时先 `shutdown(SHUT_WR)` 再 `close()`，确保数据发送完毕

### 5.6 UDP传输器实现

```python
class UDPTransfer:
    def __init__(self, host: str, port: int):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    def send(self, data: bytes):
        self.sock.sendto(data, (self.host, self.port))
```

**关键点：**
- UDP无需连接，直接发送
- 客户端需要控制发送速率（`time.sleep(0.001)`），避免服务端丢包

### 5.7 异常处理

```python
def run(self):
    try:
        while True:
            store = self._select_store()
            if store is None:
                break
            # ... 传输逻辑
    except KeyboardInterrupt:
        print("\n用户中断，退出程序")
```

**处理的异常场景：**
- `KeyboardInterrupt` - 用户按Ctrl+C中断
- 连接超时 - `sock.settimeout(10)`
- 服务器响应异常 - 检查响应内容

---

## 六、测试模块详解

### 6.1 测试架构

```
test.py
├── ServerManager        # 服务端管理器
├── generate_test_data() # 测试数据生成
├── load_test_data()     # 测试数据加载
├── transfer_data()      # 单次传输测试
├── run_benchmark()      # 基准测试运行
├── print_summary()      # 结果统计输出
└── main()               # 主入口
```

### 6.2 执行流程

```
┌─────────────────────────────────────────────────────────┐
│                       test.py                           │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. 初始化测试环境                                      │
│     ├── 清空 test_result.txt                           │
│     └── 检查/生成测试数据 (Faker)                      │
│                                                         │
│  2. 启动内嵌服务端                                      │
│     ├── ServerManager.start()                          │
│     └── Server(quiet=True)  // 静默模式                │
│                                                         │
│  3. TCP基准测试 (30轮)                                  │
│     ├── 每轮: transfer_data() → 记录统计               │
│     └── 轮次间隔: 0.1秒                                │
│                                                         │
│  4. UDP基准测试 (30轮)                                  │
│     ├── 每轮: transfer_data() → 记录统计               │
│     └── 轮次间隔: 0.1秒                                │
│                                                         │
│  5. 输出统计结果                                        │
│     ├── 控制台打印对比表格                             │
│     └── 保存到 test_result.txt                         │
│                                                         │
│  6. 停止服务端                                          │
│     ├── server.running = False                         │
│     └── 等待所有Handler线程完成                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 6.3 ServerManager - 服务端管理器

```python
class ServerManager:
    """服务端管理器 - 在后台线程运行服务端"""
    
    def start(self):
        self.server = Server(port=self.port, quiet=True)
        self.thread = threading.Thread(target=self._run_server, daemon=True)
        self.thread.start()
        time.sleep(0.5)  # 等待服务端启动
    
    def stop(self):
        self.server.running = False
        # 等待所有Handler线程完成，避免文件写入被中断导致xlsx损坏
        for handler in self.server.handlers:
            handler.join(timeout=5)
```

**关键设计：**
- `daemon=True` - 主线程退出时自动终止
- `quiet=True` - 测试时不输出日志
- `handler.join()` - 确保数据保存完成

### 6.4 测试数据生成

使用 Faker 库生成模拟数据：

```python
def generate_test_data(filepath: str, num_records: int = 100):
    fake = Faker("zh_CN")
    
    for _ in range(num_records):
        writer.writerow([
            fake.company_prefix() + fake.company_suffix(),  # 经销商
            fake.word() + fake.word(),                      # 产品描述
            round(fake.pyfloat(min_value=1, max_value=1000), 2),  # 价格
            fake.random_element(["个", "件", "箱", "盒"]),  # 单位
            fake.random_int(min=1, max=100)                 # 数量
        ])
```

### 6.5 统计指标

| 指标 | 说明 |
|------|------|
| 成功轮数 | 成功完成传输的轮次 |
| 成功率 | 成功轮数 / 总轮数 |
| 平均耗时 | 所有成功轮次的平均传输时间 |
| 最短/最长耗时 | 传输时间范围 |
| 耗时标准差 | 传输时间稳定性 |
| 平均吞吐量 | 数据传输速率 (KB/s) |

### 6.6 结果保存

所有测试结果保存到 `test_result.txt`：

```
传输性能测试结果
测试时间: 2025-12-19 15:30:00

===== TCP 传输测试 (30 轮) =====
  第  1 轮: 0.156s, 45.23 KB/s
  第  2 轮: 0.148s, 47.65 KB/s
  ...

===== UDP 传输测试 (30 轮) =====
  第  1 轮: 0.312s, 22.61 KB/s
  ...

==================================================
传输性能对比统计（平均值）
==================================================
指标                   TCP             UDP
--------------------------------------------------
成功轮数          30/30          30/30
成功率           100.0%         100.0%
平均耗时          0.152s          0.308s
...
```

---

## 七、系统亮点与创新

### 7.1 技术亮点

1. **双协议支持**
   - 同时支持TCP和UDP两种传输协议
   - 统一的接口设计，传输器可无缝切换

2. **长度前缀协议**
   - 解决TCP流式传输的消息边界问题
   - 支持任意二进制数据传输

3. **线程同步机制**
   - 使用 `threading.Event` 实现Handler就绪通知
   - 避免客户端连接时服务端尚未准备好的竞态条件

4. **数据压缩**
   - 使用zlib压缩，压缩率约50%
   - 显著减少网络传输量

5. **线程安全的数据写入**
   - DataWriter使用互斥锁保护
   - 支持多个Handler并发写入同一文件

### 7.2 工程实践

1. **面向对象设计**
   - 清晰的类职责划分
   - 良好的代码复用

2. **优雅退出**
   - 捕获 KeyboardInterrupt
   - 等待所有线程完成后再退出

3. **可配置性**
   - 命令行参数支持端口、地址配置
   - 静默模式支持测试场景

4. **完善的日志记录**
   - 传输统计日志
   - 可选的调试日志输出

### 7.3 测试完备性

1. **自动化测试**
   - 内嵌服务端，无需手动启动
   - 自动生成测试数据

2. **性能基准**
   - 多轮次测试取平均值
   - 完整的统计指标

3. **结果持久化**
   - 详细的测试结果文件
   - 便于分析和对比

---

## 八、文件结构

```
retailers-mesh/
├── server.py           # 服务端程序
├── client.py           # 客户端程序
├── test.py             # 测试程序
├── requirements.txt    # Python依赖
├── README.md           # 本报告
├── data/               # 源数据目录
│   ├── A.xlsx
│   ├── B.csv
│   ├── C.csv
│   └── D.csv
├── fake-data/          # 测试数据目录
│   └── test.csv
├── service.xlsx        # 接收数据存储文件
├── transfer_log.txt    # 传输日志
└── test_result.txt     # 测试结果
```

---

## 九、总结

本项目成功实现了一个完整的门店数据传输系统，具备以下特点：

- **协议灵活**：支持TCP和UDP双协议，适应不同网络环境
- **数据标准化**：统一处理多种格式的源数据
- **高效传输**：数据压缩 + 批量处理，提升传输效率
- **并发支持**：多线程设计，支持同时处理多个客户端
- **完善测试**：自动化测试框架，量化性能指标

系统设计遵循了良好的软件工程实践，代码结构清晰，易于维护和扩展。
