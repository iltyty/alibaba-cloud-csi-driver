import time
import os
import sys
import csv
import threading
from statistics import mean, stdev
from faker import Faker

# 导入服务端和客户端
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import Server
from client import TCPTransfer, UDPTransfer
import socket
import json
import zlib

# 测试数据目录和文件
FAKE_DATA_DIR = "fake-data"
TEST_FILE = os.path.join(FAKE_DATA_DIR, "test.csv")
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8000
TEST_ROUNDS = 30


class ServerManager:
    """服务端管理器，用于在测试中启动和停止服务端"""
    def __init__(self, port: int = SERVER_PORT):
        self.port = port
        self.server = None
        self.thread = None
    
    def start(self):
        self.server = Server(port=self.port, quiet=True)
        self.thread = threading.Thread(target=self._run_server, daemon=True)
        self.thread.start()
        time.sleep(0.5)  # 等待服务端启动
        print(f"服务端已启动，端口: {self.port}")
    
    def _run_server(self):
        self.server.start()
    
    def stop(self):
        if self.server:
            self.server.running = False
            # 等待所有Handler线程完成，避免文件写入被中断导致xlsx损坏
            for handler in self.server.handlers:
                handler.join(timeout=5)
        print("服务端已停止")


def generate_test_data(filepath: str, num_records: int = 100):
    """使用Faker生成测试数据"""
    fake = Faker("zh_CN")
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["retailer_code", "prod_desc", "normal_price", "unit_dimension", "unit_number"])
        
        for _ in range(num_records):
            writer.writerow([
                fake.company_prefix() + fake.company_suffix(),
                fake.word() + fake.word(),
                round(fake.pyfloat(min_value=1, max_value=1000, right_digits=2), 2),
                fake.random_element(["个", "件", "箱", "盒", "袋", "瓶"]),
                fake.random_int(min=1, max=100)
            ])
    
    print(f"已生成测试数据: {filepath}, 共 {num_records} 条记录")


def load_test_data(filepath: str) -> list:
    """加载测试数据"""
    records = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append({
                "retailer_code": row["retailer_code"],
                "prod_desc": row["prod_desc"],
                "normal_price": float(row["normal_price"]),
                "unit_dimension": row["unit_dimension"],
                "unit_number": int(row["unit_number"])
            })
    return records


def send_udp_request(host: str, port: int, message: str) -> str:
    """发送UDP请求并接收响应"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(10)
    sock.sendto(message.encode("utf-8"), (host, port))
    response, _ = sock.recvfrom(1024)
    sock.close()
    return response.decode("utf-8")


def transfer_data(records: list, protocol: str, host: str, port: int) -> dict:
    """执行一次数据传输，返回统计信息"""
    # 请求连接
    response = send_udp_request(host, port, "数据传输请求")
    
    # 选择协议
    choice = "1" if protocol == "TCP" else "0"
    response = send_udp_request(host, port, choice)
    
    if "我已准备完毕" not in response:
        raise Exception(f"服务器响应异常: {response}")
    
    data_port = int(response.split(":")[-1])
    
    # 创建传输器
    if protocol == "TCP":
        transfer = TCPTransfer(host, data_port)
    else:
        transfer = UDPTransfer(host, data_port)
    
    transfer.connect()
    
    # 开始传输
    start_time = time.time()
    total_bytes = 0
    
    for idx, record in enumerate(records):
        is_last = (idx == len(records) - 1)
        packet = {
            "store": "TEST",
            "index": idx,
            "data": record,
            "last": is_last
        }
        
        compressed = zlib.compress(json.dumps(packet).encode("utf-8"))
        transfer.send(compressed)
        total_bytes += len(compressed)
        
        if protocol == "UDP":
            # UDP无流控，发送过快会导致丢包，需控制发送速率
            time.sleep(0.001)
    
    end_time = time.time()
    transfer.close()
    
    duration = end_time - start_time
    return {
        "duration": duration,
        "records": len(records),
        "bytes": total_bytes,
        "throughput": total_bytes / duration if duration > 0 else 0
    }


TEST_RESULT_FILE = "test_result.txt"


def run_benchmark(records: list, protocol: str, rounds: int = TEST_ROUNDS) -> dict:
    """运行基准测试"""
    results = []
    
    print(f"\n===== {protocol} 传输测试 ({rounds} 轮) =====")
    
    # 将每轮详细结果写入文件
    with open(TEST_RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n===== {protocol} 传输测试 ({rounds} 轮) =====\n")
        
        for i in range(rounds):
            try:
                stats = transfer_data(records, protocol, SERVER_HOST, SERVER_PORT)
                results.append(stats)
                f.write(f"  第 {i+1:2d} 轮: {stats['duration']:.3f}s, {stats['throughput']/1024:.2f} KB/s\n")
                # 等待服务端Handler线程完成数据保存和端口释放，避免资源竞争
                time.sleep(0.1)
            except Exception as e:
                f.write(f"  第 {i+1:2d} 轮: 失败 - {e}\n")
    
    print(f"  完成 {len(results)}/{rounds} 轮")
    
    if not results:
        return None
    
    durations = [r["duration"] for r in results]
    throughputs = [r["throughput"] for r in results]
    
    summary = {
        "protocol": protocol,
        "rounds": len(results),
        "success_rate": len(results) / rounds * 100,
        "avg_duration": mean(durations),
        "min_duration": min(durations),
        "max_duration": max(durations),
        "std_duration": stdev(durations) if len(durations) > 1 else 0,
        "avg_throughput": mean(throughputs),
        "total_records": results[0]["records"],
        "total_bytes": results[0]["bytes"]
    }
    
    return summary


def print_summary(tcp_summary: dict, udp_summary: dict):
    """打印统计摘要"""
    print("\n" + "=" * 60)
    print("传输性能对比统计")
    print("=" * 60)
    
    headers = ["指标", "TCP", "UDP"]
    rows = [
        ("成功轮数", f"{tcp_summary['rounds']}/{TEST_ROUNDS}", f"{udp_summary['rounds']}/{TEST_ROUNDS}"),
        ("成功率", f"{tcp_summary['success_rate']:.1f}%", f"{udp_summary['success_rate']:.1f}%"),
        ("平均耗时", f"{tcp_summary['avg_duration']:.3f}s", f"{udp_summary['avg_duration']:.3f}s"),
        ("最短耗时", f"{tcp_summary['min_duration']:.3f}s", f"{udp_summary['min_duration']:.3f}s"),
        ("最长耗时", f"{tcp_summary['max_duration']:.3f}s", f"{udp_summary['max_duration']:.3f}s"),
        ("耗时标准差", f"{tcp_summary['std_duration']:.3f}s", f"{udp_summary['std_duration']:.3f}s"),
        ("平均吞吐量", f"{tcp_summary['avg_throughput']/1024:.2f} KB/s", f"{udp_summary['avg_throughput']/1024:.2f} KB/s"),
        ("记录数", f"{tcp_summary['total_records']}", f"{udp_summary['total_records']}"),
        ("数据量", f"{tcp_summary['total_bytes']/1024:.2f} KB", f"{udp_summary['total_bytes']/1024:.2f} KB"),
    ]
    
    col_widths = [15, 20, 20]
    print(f"{'─' * col_widths[0]}┬{'─' * col_widths[1]}┬{'─' * col_widths[2]}")
    print(f"{headers[0]:<{col_widths[0]}}│{headers[1]:^{col_widths[1]}}│{headers[2]:^{col_widths[2]}}")
    print(f"{'─' * col_widths[0]}┼{'─' * col_widths[1]}┼{'─' * col_widths[2]}")
    
    for row in rows:
        print(f"{row[0]:<{col_widths[0]}}│{row[1]:^{col_widths[1]}}│{row[2]:^{col_widths[2]}}")
    
    print(f"{'─' * col_widths[0]}┴{'─' * col_widths[1]}┴{'─' * col_widths[2]}")
    
    # 将统计摘要追加到test_result.txt
    with open(TEST_RESULT_FILE, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 50 + "\n")
        f.write("传输性能对比统计（平均值）\n")
        f.write("=" * 50 + "\n")
        f.write(f"{'指标':<12} {'TCP':>15} {'UDP':>15}\n")
        f.write("-" * 50 + "\n")
        for row in rows:
            f.write(f"{row[0]:<12} {row[1]:>15} {row[2]:>15}\n")
        f.write("-" * 50 + "\n")
    
    print(f"\n结果已保存到 {TEST_RESULT_FILE}")


def main():
    # 清空test_result.txt
    with open(TEST_RESULT_FILE, "w", encoding="utf-8") as f:
        f.write(f"传输性能测试结果\n测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # 检查测试数据
    if not os.path.exists(TEST_FILE):
        print(f"测试数据文件不存在，正在生成...")
        generate_test_data(TEST_FILE, num_records=100)
    else:
        print(f"使用已有测试数据: {TEST_FILE}")
    
    records = load_test_data(TEST_FILE)
    print(f"加载了 {len(records)} 条测试记录")
    
    # 自动启动服务端
    server_manager = ServerManager(SERVER_PORT)
    server_manager.start()
    
    try:
        tcp_summary = run_benchmark(records, "TCP", TEST_ROUNDS)
        udp_summary = run_benchmark(records, "UDP", TEST_ROUNDS)
        if tcp_summary and udp_summary:
            print_summary(tcp_summary, udp_summary)
        else:
            print("测试失败")
    finally:
        server_manager.stop()


if __name__ == "__main__":
    main()
