import socket
import threading
import json
import zlib
import time
import os
import struct
from datetime import datetime
from openpyxl import Workbook, load_workbook


class TransferStats:
    """传输统计类"""
    def __init__(self, store: str, protocol: str):
        self.store = store
        self.protocol = protocol
        self.start_time = None
        self.end_time = None
        self.record_count = 0
    
    def start(self):
        self.start_time = time.time()
    
    def finish(self):
        self.end_time = time.time()
    
    @property
    def duration(self) -> float:
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0
    
    def save_log(self, log_file: str = "transfer_log.txt"):
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"门店: {self.store}, 协议: {self.protocol}, "
                    f"记录数: {self.record_count}, "
                    f"断开时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}, "
                    f"传输时长: {self.duration:.3f}秒\n")


class DataWriter:
    """数据写入器"""
    def __init__(self, output_file: str = "service.xlsx"):
        self.output_file = output_file
        self.lock = threading.Lock()
        self._init_workbook()
    
    def _init_workbook(self):
        if os.path.exists(self.output_file):
            self.wb = load_workbook(self.output_file)
        else:
            self.wb = Workbook()
            self.wb.remove(self.wb.active)
    
    def write_record(self, store: str, data: dict):
        with self.lock:
            if store not in self.wb.sheetnames:
                ws = self.wb.create_sheet(store)
                ws.append(["retailer_code", "prod_desc", "normal_price", 
                          "unit_dimension", "unit_number"])
            else:
                ws = self.wb[store]
            
            ws.append([
                data.get("retailer_code", ""),
                data.get("prod_desc", ""),
                data.get("normal_price", ""),
                data.get("unit_dimension", ""),
                data.get("unit_number", "")
            ])
    
    def save(self):
        with self.lock:
            self.wb.save(self.output_file)


class TCPHandler(threading.Thread):
    """TCP数据接收处理器"""
    def __init__(self, port: int, writer: DataWriter, store: str, quiet: bool = False):
        super().__init__()
        self.port = port
        self.writer = writer
        self.store = store
        self.stats = TransferStats(store, "TCP")
        self.ready = threading.Event()
        self.quiet = quiet # 不打印任何日志，测试时会用到
    
    def _log(self, msg: str):
        if not self.quiet:
            print(msg)
    
    def run(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("", self.port))
        server.listen(1)
        server.settimeout(60)
        self.ready.set()
        
        try:
            conn, addr = server.accept()
            self._log(f"[TCP] 客户端 {addr} 已连接")
            conn.settimeout(30)
            buffer = b""
            
            while True:
                try:
                    chunk = conn.recv(65536)
                    if not chunk:
                        break
                    buffer += chunk
                    
                    # 解析长度前缀协议：每个数据包 = 4字节长度头 + 实际数据
                    while len(buffer) >= 4:
                        # 从前4字节解析出数据长度（大端序无符号整数）
                        msg_len = struct.unpack('>I', buffer[:4])[0]
                        # 如果缓冲区数据不足一个完整包，等待更多数据
                        if len(buffer) < 4 + msg_len:
                            break
                        # 提取完整的数据包
                        data = buffer[4:4+msg_len]
                        # 移除已处理的数据，保留剩余部分
                        buffer = buffer[4+msg_len:]
                        
                        try:
                            decompressed = zlib.decompress(data)
                            record = json.loads(decompressed.decode("utf-8"))
                            
                            if self.stats.start_time is None:
                                self.stats.start()
                            
                            self.writer.write_record(record["store"], record["data"])
                            self.stats.record_count += 1
                            
                            if record.get("last", False):
                                self.stats.finish()
                                self.writer.save()
                                self._log(f"[TCP] 门店 {record['store']} 数据接收并保存完成，共 {self.stats.record_count} 条")
                                self.stats.save_log()
                                return
                        except Exception as e:
                            self._log(f"[TCP] 解析数据失败: {e}")
                            continue
                except socket.timeout:
                    break
            
            # 连接关闭但未收到last标记时也保存数据
            if self.stats.record_count > 0:
                self.stats.finish()
                self.writer.save()
                self._log(f"[TCP] 数据接收完成（连接关闭），共 {self.stats.record_count} 条")
                self.stats.save_log()
        except socket.timeout:
            self._log(f"[TCP] 等待客户端连接超时")
        except Exception as e:
            self._log(f"[TCP] 错误: {e}")
        finally:
            server.close()


class UDPHandler(threading.Thread):
    """UDP数据接收处理器"""
    def __init__(self, port: int, writer: DataWriter, store: str, quiet: bool = False):
        super().__init__()
        self.port = port
        self.writer = writer
        self.store = store
        self.stats = TransferStats(store, "UDP")
        self.ready = threading.Event()
        self.quiet = quiet
    
    def _log(self, msg: str):
        if not self.quiet:
            print(msg)
    
    def run(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server.bind(("", self.port))
        server.settimeout(10)
        self.ready.set()
        
        try:
            while True:
                try:
                    data, addr = server.recvfrom(65536)
                    decompressed = zlib.decompress(data)
                    record = json.loads(decompressed.decode("utf-8"))
                    
                    if self.stats.start_time is None:
                        self.stats.start()
                    
                    self.writer.write_record(record["store"], record["data"])
                    self.stats.record_count += 1
                    
                    if record.get("last", False):
                        self.stats.finish()
                        self.writer.save()
                        self._log(f"[UDP] 门店 {record['store']} 数据接收并保存完成，共 {self.stats.record_count} 条")
                        self.stats.save_log()
                        return
                except socket.timeout:
                    if self.stats.record_count > 0:
                        self.stats.finish()
                        self.writer.save()
                        self._log(f"[UDP] 数据接收完成（超时），共 {self.stats.record_count} 条")
                        self.stats.save_log()
                    break
                except Exception:
                    continue
        finally:
            server.close()


class Server:
    """服务端主类"""
    def __init__(self, port: int = 8000, quiet: bool = False):
        self.port = port
        self.writer = DataWriter()
        self.running = False
        self.quiet = quiet
        self.handlers = []  # 跟踪所有活跃的Handler线程
    
    def _log(self, msg: str):
        if not self.quiet:
            print(msg)
    
    def _find_free_port(self) -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            return s.getsockname()[1]
    
    def _handle_client(self, data: bytes, addr: tuple, sock: socket.socket):
        message = data.decode("utf-8").strip()
        
        if message == "数据传输请求":
            self._log(f"收到来自 {addr} 的数据传输请求")
            response = "请选择数据传输时的通信方式，基于TCP请选择1，基于UDP请选择0"
            sock.sendto(response.encode("utf-8"), addr)
        
        elif message in ["0", "1"]:
            port = self._find_free_port()
            protocol = "TCP" if message == "1" else "UDP"
            self._log(f"客户端 {addr} 选择 {protocol} 传输，分配端口: {port}")
            store = "unknown"
            
            if message == "1":
                handler = TCPHandler(port, self.writer, store, quiet=self.quiet)
            else:
                handler = UDPHandler(port, self.writer, store, quiet=self.quiet)
            
            self.handlers.append(handler)
            handler.start()
            handler.ready.wait(timeout=5)
            response = f"我已准备完毕，请开始传输:{port}"
            sock.sendto(response.encode("utf-8"), addr)
    
    def start(self):
        self.running = True
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("", self.port))
        self._log(f"服务端已启动，监听端口: {self.port}")
        
        try:
            while self.running:
                try:
                    sock.settimeout(1)
                    data, addr = sock.recvfrom(1024)
                    threading.Thread(target=self._handle_client, 
                                   args=(data, addr, sock)).start()
                except socket.timeout:
                    continue
        except KeyboardInterrupt:
            self._log("\n服务端已停止")
        finally:
            sock.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="数据传输服务端")
    parser.add_argument("-p", "--port", type=int, default=8000, help="监听端口")
    args = parser.parse_args()
    
    server = Server(port=args.port)
    server.start()
