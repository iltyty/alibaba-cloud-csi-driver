import socket
import json
import zlib
import time
import os
import pandas as pd
from openpyxl import load_workbook


import struct


class DataLoader:
    """数据加载器"""
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self.store_files = {
            "A": "A.xlsx",
            "B": "B.csv",
            "C": "C.csv",
            "D": "D.csv"
        }
    
    def load(self, store: str):
        """加载门店数据并返回标准化记录"""
        filepath = os.path.join(self.data_dir, self.store_files[store])
        
        if store == "A":
            return self._load_xlsx(filepath, store)
        elif store == "B":
            return self._load_csv_b(filepath, store)
        elif store == "C":
            return self._load_csv_c(filepath, store)
        else:
            return self._load_csv_d(filepath, store)
    
    def _load_xlsx(self, filepath: str, store: str):
        wb = load_workbook(filepath, data_only=True)
        ws = wb.active
        headers = [cell.value for cell in ws[1]]
        
        records = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            data = dict(zip(headers, row))
            records.append({
                "retailer_code": data.get("retailer_code", ""),
                "prod_desc": data.get("prod_desc", ""),
                "normal_price": data.get("normal_price", 0),
                "unit_dimension": data.get("unit_dimension", ""),
                "unit_number": data.get("unit_number", 0)
            })
        return records
    
    def _load_csv_b(self, filepath: str, store: str):
        df = pd.read_csv(filepath, encoding="utf-8")
        records = []
        for _, row in df.iterrows():
            records.append({
                "retailer_code": row.get("retailer_code", ""),
                "prod_desc": row.get("prod_desc", ""),
                "normal_price": 0,
                "unit_dimension": row.get("unit_dimension", ""),
                "unit_number": row.get("unit_number", 0)
            })
        return records
    
    def _load_csv_c(self, filepath: str, store: str):
        df = pd.read_csv(filepath, encoding="utf-8", header=None)
        records = []
        for idx, row in df.iterrows():
            if idx == 0:
                continue
            records.append({
                "retailer_code": row.iloc[0] if pd.notna(row.iloc[0]) else "",
                "prod_desc": row.iloc[7] if len(row) > 7 and pd.notna(row.iloc[7]) else "",
                "normal_price": row.iloc[10] if len(row) > 10 and pd.notna(row.iloc[10]) else 0,
                "unit_dimension": row.iloc[13] if len(row) > 13 and pd.notna(row.iloc[13]) else "",
                "unit_number": row.iloc[16] if len(row) > 16 and pd.notna(row.iloc[16]) else 0
            })
        return records
    
    def _load_csv_d(self, filepath: str, store: str):
        df = pd.read_csv(filepath, encoding="utf-8", header=None)
        records = []
        for idx, row in df.iterrows():
            if idx == 0:
                continue
            records.append({
                "retailer_code": row.iloc[0] if pd.notna(row.iloc[0]) else "",
                "prod_desc": row.iloc[4] if len(row) > 4 and pd.notna(row.iloc[4]) else "",
                "normal_price": row.iloc[6] if len(row) > 6 and pd.notna(row.iloc[6]) else 0,
                "unit_dimension": row.iloc[14] if len(row) > 14 and pd.notna(row.iloc[14]) else "",
                "unit_number": row.iloc[7] if len(row) > 7 and pd.notna(row.iloc[7]) else 0
            })
        return records


class TransferStats:
    """客户端传输统计"""
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.record_count = 0
    
    def start(self):
        self.start_time = time.time()
    
    def finish(self):
        self.end_time = time.time()
    
    @property
    def duration(self) -> float:
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0


class TCPTransfer:
    """TCP传输器"""
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.sock = None
    
    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.sock.connect((self.host, self.port))
        except Exception as e:
            print(f"TCP连接失败: {e}")
            raise
    
    def send(self, data: bytes):
        # 发送4字节长度前缀 + 数据
        self.sock.sendall(struct.pack('>I', len(data)) + data)
    
    def close(self):
        if self.sock:
            self.sock.shutdown(socket.SHUT_WR)
            time.sleep(0.1)
            self.sock.close()


class UDPTransfer:
    """UDP传输器"""
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    def connect(self):
        pass
    
    def send(self, data: bytes):
        self.sock.sendto(data, (self.host, self.port))
    
    def close(self):
        self.sock.close()


class Client:
    """客户端主类"""
    def __init__(self, host: str = "127.0.0.1", port: int = 8000):
        self.host = host
        self.port = port
        self.loader = DataLoader()
    
    def _send_request(self, message: str) -> str:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(10)
        sock.sendto(message.encode("utf-8"), (self.host, self.port))
        response, _ = sock.recvfrom(1024)
        sock.close()
        return response.decode("utf-8")
    
    def _select_store(self) -> str:
        while True:
            print("选择想要传输的门店信息：A/B/C/D，退出请输入exit")
            choice = input().strip().upper()
            
            if choice == "EXIT":
                return None
            
            if choice in ["A", "B", "C", "D"]:
                return choice
            
            print("门店不存在，请重新输入")
    
    def _select_protocol(self) -> str:
        while True:
            choice = input().strip()
            if choice in ["0", "1"]:
                return choice
            print("请输入0或1")
    
    def _transfer_data(self, store: str, protocol: str, data_port: int):
        records = self.loader.load(store)
        total = len(records)
        
        if protocol == "1":
            transfer = TCPTransfer(self.host, data_port)
        else:
            transfer = UDPTransfer(self.host, data_port)
        
        transfer.connect()
        stats = TransferStats()
        stats.start()
        
        print("开始传输数据")
        
        for idx, record in enumerate(records):
            is_last = (idx == total - 1)
            packet = {
                "store": store,
                "index": idx,
                "data": record,
                "last": is_last
            }
            
            compressed = zlib.compress(json.dumps(packet).encode("utf-8"))
            transfer.send(compressed)
            stats.record_count += 1
            
            # UDP需要控制发送速率
            if protocol == "0":
                time.sleep(0.001)
        
        stats.finish()
        transfer.close()
        
        print(f"数据传输完成，共传输 {stats.record_count} 条记录，耗时 {stats.duration:.3f} 秒")
    
    def run(self):
        try:
            while True:
                store = self._select_store()
                if store is None:
                    break
                
                # 发送数据传输请求
                response = self._send_request("数据传输请求")
                print(response)
                
                # 选择传输协议
                protocol = self._select_protocol()
                
                # 获取数据传输端口
                response = self._send_request(protocol)
                if "我已准备完毕" in response:
                    data_port = int(response.split(":")[-1])
                    self._transfer_data(store, protocol, data_port)
                    break
                else:
                    print("服务器响应异常")
        except KeyboardInterrupt:
            print("\n用户中断，退出程序")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="数据传输客户端")
    parser.add_argument("-H", "--host", type=str, default="127.0.0.1", help="服务器地址")
    parser.add_argument("-p", "--port", type=int, default=8000, help="服务器端口")
    args = parser.parse_args()
    
    client = Client(host=args.host, port=args.port)
    client.run()
